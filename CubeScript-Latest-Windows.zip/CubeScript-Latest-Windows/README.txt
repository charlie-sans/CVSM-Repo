Welcome to the first official release of CubeScript for windows!

##############################
####Cubescript version 1.1####
##############################

Since this release is the first one of many, i want to thank you all for sticking around for so long while i work on this compiler.

For now, the CVSM is written in Python as i already had a implementation from an older project for mine awhile ago.

the official website for cubescript can be found at, https://Cubescript.vercel.app

Cubescript is a transpiled language, just like how TypeScript is{ for now at least }. 

it will change over time so please be weary about that!

currently, the syntax is strongly recommend to be used like C# as i'm still working on the backend of the compiler!

you can learn Cubescript from the official documentation at https://CubeScript.vercel.app/learn/functions

this folder contains the Compiler, the official Syntax Hightlighter, the official Home libary and this verry readme file


you can create a new cubescript console project using "./cusp new"
just enter the name of the project, reload the editor, then use "./cusp program.cusp" to run the code


struct Main()
{
print("take care and have fun!");
}